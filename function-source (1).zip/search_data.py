import requests  
import json

def TPE():    
    url = "https://tcgbusfs.blob.core.windows.net/dotapp/youbike/v2/youbike_immediate.json"      
    data = requests.get(url).text
    return json.loads(data)
    
def NTP(): 
    url_template = "https://data.ntpc.gov.tw/api/datasets/010e5b15-3823-4b20-b401-b1cf000550c5/json?page={}&size=1500"
    
    # 第一頁
    data1 = requests.get(url_template.format(0)).text
    bike = json.loads(data1)
    
    # 第二頁
    data2 = requests.get(url_template.format(1)).text
    bike.extend(json.loads(data2))
    return bike
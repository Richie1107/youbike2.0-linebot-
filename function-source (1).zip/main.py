import search_data
import json,requests


def serach_bike(request):
    try:
        data = request.get_json()
        city = data.get('city','')
        print(data)

        if city == 'TPE':
            response = json.dumps(search_data.TPE())
            return response, 200
        elif city == 'NTP':
            response = json.dumps(search_data.NTP())
            return response, 200
        else:
            return '查無資料', 200
        print(response)
    except InvalidSignatureError:
        return {
            'statusCode': 400,
            'body': json.dumps('InvalidSignature') }        
    
    # === [ 發生錯誤的LineBotApi內容(LineBotApiError)的程式區段 ] ===
    except LineBotApiError as e:                
        error_message = f'呼叫 GCF 時發生意外錯誤(AWS_search): {e.message}'
        logger.error(error_message)
        
        url = 'https://notify-api.line.me/api/notify'
        token = 'R4BSFVdXCWINsjn76YcWAj41kZRjLgSGMaR96FoGzMd'
        headers = {
            'Authorization': 'Bearer ' + token
        }
        data = {
            'message': f'function error: {str(error_message)}'
        }
        requests.post(url, headers=headers, data=data)
        return {
            'statusCode': 400,
            'body': json.dumps(traceback.format_exc()) }
    return 'OK'
from linebot.models import FlexSendMessage,TextSendMessage
import requests  
import json
from datetime import datetime 
import time
import urllib.parse


def TCC_search(latitude = None , longitude = None , user_message = None ):           
    url = "https://datacenter.taichung.gov.tw/swagger/OpenData/86dfad5c-540c-4479-bb7d-d7439d34eeb1"     
    data = requests.get(url).text
    bikeList = json.loads(data)       
    bike_data = bikeList['retVal']
    
    update_time = format_update_time(bike_data[0]['mday'])
    
    if user_message != '' and user_message is not None:
        return search_message(user_message,bike_data,update_time)
    else:
        return search_location(latitude, longitude, bike_data,update_time)

def TPE_search(latitude = None , longitude = None , user_message = None ):           
        #設定post條件
    gcf_url = "https://asia-east1-my-project-search-407814.cloudfunctions.net/aws"
    
    headers = {"Content-Type": "application/json"}
    
    payload = {"city":"TPE"}
    
     # 使用 requests 模組進行 HTTP POST 請求
    response = requests.post(gcf_url, json=payload, headers=headers)
     # 處理響應
    if response.status_code == 200:
        print(response)
    else:
        print(f"GCF 函數執行失敗，HTTP 響應碼: {response.status_code}")
    bike_data = response.json()
    
    update_time = format_update_time(bike_data[0]['mday'])
    
    if user_message != '' and user_message is not None:
        return search_message(user_message,bike_data,update_time)
    else:
        return search_location(latitude, longitude, bike_data,update_time)

def NTP_search(latitude = None , longitude = None , user_message = None ):           
        #設定post條件
    gcf_url = "https://asia-east1-my-project-search-407814.cloudfunctions.net/aws"
    
    headers = {"Content-Type": "application/json"}
    
    payload = {"city":"NTP"}
    
     # 使用 requests 模組進行 HTTP POST 請求
    response = requests.post(gcf_url, json=payload, headers=headers)
     # 處理響應
    if response.status_code == 200:
        print(response)
    else:
        print(f"GCF 函數執行失敗，HTTP 響應碼: {response.status_code}")

    bike_data = response.json()
    print (bike_data)
    update_time = format_update_time(bike_data[0]['mday'])
    
    if user_message != '' and user_message is not None:
        return search_message(user_message,bike_data,update_time)
    else:
        return search_location(latitude, longitude, bike_data,update_time)




def search_message(user_message,bike_data,update_time):
    st_time = time.time()
    contents=dict()
    contents['type']='carousel'
    bubbles=[] 
    
    if '路' in user_message  :
        p = 1
        for i in range(len(bike_data)):
            ed_time = time.time()
            if p <= 10 and int(ed_time - st_time) <= 15:
                if bike_data[i]['sarea'].find(user_message) >= 0:
                  bubble = create_bike_bubble(bike_data[i],update_time)
                  bubbles.append(bubble)
                  p += 1
                  ed_time = time.time()  

    else:        
        p = 1
        for i in range(len(bike_data)):
            ed_time = time.time()
            if p <= 10 and int(ed_time - st_time) <= 15:
                if bike_data[i]['sna'].find(user_message) >= 0:
                    bubble = create_bike_bubble(bike_data[i],update_time)
                    bubbles.append(bubble)
                    p += 1
                    ed_time = time.time()
                    
    if len(bubbles)!=0:
        contents['contents']=bubbles
        message = FlexSendMessage(alt_text='搜尋站點結果',contents=contents)
    elif len(bubbles)==0:
        message = TextSendMessage(text='未搜尋到youbike2.0車站資訊')
    return message


def format_update_time(date):
    date_format='%Y%m%d%H%M%S'
    try:
        return str(datetime.strptime(date, date_format)) 
    except ValueError:
        return '查無更新時間'

def search_location(latitude, longitude, bike_data,update_time):
    st_time = time.time()
    contents=dict()
    contents['type']='carousel'
    bubbles=[]  

    p = 1
    for i in range(len(bike_data)):
        ed_time = time.time()
        if p <= 10 and int(ed_time - st_time) <= 15:
            lat = float(bike_data[i]['lat'])
            lng = float(bike_data[i]['lng'])
            if abs(latitude - lat) < 0.01 and abs(longitude - lng) < 0.01:
                bubble = create_bike_bubble(bike_data[i],update_time)
                bubbles.append(bubble)
                p += 1
                ed_time = time.time()

    if len(bubbles)!=0:
        contents['contents']=bubbles
        message = FlexSendMessage(alt_text='搜尋站點結果',contents=contents)
    elif len(bubbles)==0:
        message = TextSendMessage(text='附近未搜尋到youbike2.0車站資訊')
    print(message)
    return message


def create_bike_bubble(bike_info,update_time):
    bubble = {  "type": "bubble",
                            "body": {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                {
                                    "type": "text",
                                    "text": bike_info['sna'].replace('YouBike2.0_',''),
                                    "weight": "bold",
                                    "size": "xl",
                                    "margin": "md",
                                    "wrap": True,
                                    "style": "normal"
                                },
                                {
                                    "type": "text",
                                    "text": "位置資訊",
                                    "margin": "md",
                                    "size": "lg",
                                    "align": "start",
                                    "decoration": "none"
                                },
                                {
                                    "type": "separator"
                                },
                                 {
                                    "type": "box",
                                    "layout": "horizontal",
                                    "contents": [
                                        {
                                            "type": "text",
                                            "text": "地址:" + bike_info['ar'],
                                            "color":"#0000E3",
                                            "size": "sm",
                                            "wrap": True
                                        }
                                    ],
                                    "margin": "sm",
                                    "action": {
                                        "type": "uri",
                                        "label": "查看地圖",
                                        "uri": "https://www.google.com/maps?q="
                                        + urllib.parse.quote(bike_info['ar'])
                                    }
                                },
                                {
                                    "type": "separator",
                                    "margin": "xxl"
                                },
                                {
                                    "type": "text",
                                    "text": "可租借車輛",
                                    "margin": "md",
                                    "size": "lg",
                                    "align": "start"
                                },
                                {
                                    "type": "box",
                                    "layout": "vertical",
                                    "margin": "sm",
                                    "spacing": "sm",
                                    "contents": [
                                    {
                                        "type": "text",
                                        "text": str(bike_info['sbi']),
                                        "size": "sm",
                                        "wrap": True,
                                        "align": "start"
                                    }
                                    ]
                                },
                                {
                                    "type": "separator",
                                    "margin": "xxl"
                                },
                                {
                                    "type": "text",
                                    "text": "可停放車輛",
                                    "margin": "md",
                                    "align": "start",
                                    "size": "lg"
                                },
                                {
                                    "type": "box",
                                    "layout": "vertical",
                                    "margin": "sm",
                                    "spacing": "sm",
                                    "contents": [
                                    {
                                        "type": "text",
                                        "text": str(bike_info['bemp']),
                                        "size": "sm",
                                        "wrap": True,
                                        "align": "start"
                                    }
                                    ]
                                },
                                {
                                    "type": "separator",
                                    "margin": "xxl"
                                },
                                {
                                    "type": "box",
                                    "layout": "horizontal",
                                    "margin": "md",
                                    "contents": [
                                    {
                                        "type": "text",
                                        "text": "更新時間:",
                                        "size": "xs",
                                        "color": "#aaaaaa",
                                        "flex": 0
                                    },
                                    {
                                        "type": "text",
                                        "text": update_time,
                                        "color": "#aaaaaa",
                                        "size": "xs",
                                        "align": "end"
                                    }
                                    ]
                                }
                                ]
                            },
                            "styles": {
                                "footer": {
                                "separator": True
                                }
                            }
                            }

    return bubble
    

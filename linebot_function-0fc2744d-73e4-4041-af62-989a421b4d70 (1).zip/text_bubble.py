from linebot.models import FlexSendMessage

def butten_text():
    contents=dict()
    contents['type']='carousel'
    bubbles=[]  
    bubble = {  "type": "bubble",
                            "body": {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                {
                                    "type": "text",
                                    "text": "提供的服務項目:",
                                    "weight": "bold",
                                    "size": "xl",
                                    "margin": "md",
                                    "wrap": True,
                                    "style": "normal",
                                    "color": "#000088"
                                },
                                {
                                "type": "box",
                                "layout": "vertical",
                                "spacing": "sm",
                                "contents": [
                                {
                                    "type": "text",
                                    "text": "選擇城市",
                                    "color": "#00AA00",
                                    "size": "sm",
                                    "flex": 1
                                }
                                            ]
                                },
                                {
                                "type": "box",
                                "layout": "horizontal",
                                "margin": "lg",
                                "spacing": "sm",            
                                "contents": [
                                {
                                    "type": "button",
                                    "style": "secondary",
                                    "color": "#1DB446",
                                    "action": {
                                               "type": "message",
                                               "label": "台北",
                                               "text": "台北"
                                               }
                                }
                                            ]
                                },
                                {
                                "type": "box",
                                "layout": "horizontal",
                                "margin": "sm",
                                "spacing": "sm",
                                "contents": [
                                {
                                    "type": "button",
                                    "style": "secondary",
                                    "color": "#1DB446",
                                    "action": {
                                                "type": "message",
                                                "label": "新北",
                                                "text": "新北"
                                              }
                                }
                                            ]
                                },
                                {
                                "type": "box",
                                "layout": "vertical",
                                "margin": "sm",
                                "spacing": "sm",
                                "contents": [
                                {
                                    "type": "button",
                                    "style": "secondary",
                                    "color": "#1DB446",
                                    "action": {
                                                "type": "message",
                                                "label": "台中",
                                                "text": "台中"
                                              }
                                }
                                            ]
                                },
                                {
                                "type": "box",
                                "layout": "vertical",
                                "margin": "sm",
                                "spacing": "sm",
                                "contents": [
                                {
                                    "type": "button",
                                    "style": "secondary",
                                    "color": "#1DB446",
                                    "action": {
                                                "type": "uri",
                                                "label": "位置資訊",
                                                "uri": "https://line.me/R/nv/location/"
                                              }
                                }
                                            ]
                                }
                                ]
                                }
            }
                
    bubbles.append(bubble)
    contents['contents']=bubbles
    message = FlexSendMessage(alt_text='請選擇服務項目',contents=contents)
    print (message)
    return message
